from collections import OrderedDict
from util import *
import time
import random

agents = OrderedDict()

def update_agents():
    global agents

    agentsinDB = readFromDB(agentsDB)
    agents = OrderedDict()
    for agent in agentsinDB:
        agents[agent.name] = agent

def list_agents():
    update_agents()
    success("Active Agents")
    for i in agents:
        print(f"\\-- {agents[i].name} | {agents[i].remoteip} | {agents[i].hostname}")

def interact_agents(args):
    update_agents()
    if len(args) != 1:
        error("Wrong arguments")
    else:
        name = args[0]
        agents[name].interact()

