import string
import random
from util import *
import flask
import sys 
from multiprocessing import Process
import threading
import logging
from AgentHelpers import *
from agents import *


class Listener():

    def __init__(self, host, port, name):
        self.host = host
        self.port = port
        self.id   = name
        self.app = flask.Flask(__name__)
        @self.app.route("/reg", methods=['POST'])
        def registerAgent():
            name     = ''.join(random.choice(string.ascii_uppercase) for i in range(6))
            remoteip = flask.request.remote_addr
            hostname = flask.request.form.get("name")
            success("Agent {} checked in.".format(name))
            writeToDB(agentsDB,Agent(name,self.id,remoteip,hostname))
            return (name, 200)
        
    def run(self):
        #log = logging.getLogger('werkzeug')
        #log.setLevel(logging.ERROR)
        #self.app.logger.disabled = True
        self.app.run(port=self.port, host=self.host)
        


    def start(self):
        success(f"Starting listener {self.id} on {self.host}:{self.port}")
        self.server = Process(target=self.run)
        #cli = sys.modules['flask.cli']
        #cli.show_server_banner = lambda *x: None
        self.daemon = threading.Thread(name = self.id,
                                       target = self.server.start,
                                       args = ())
        self.daemon.daemon = True
        self.daemon.run()

        self.isRunning = True
    
    def stop(self):
        self.server.terminate()
        self.isRunning = False
