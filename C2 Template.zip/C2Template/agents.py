import menu

class Agent:
    def __init__(self,name,listener,remoteip,hostname):
        self.name = name
        self.listener = listener
        self.hostname = hostname
        self.remoteip = remoteip
        self.menu = menu.Menu(self.name)

        self.menu.registerCommand("shell","Execute a shell command","<command>")
    

    def interact(self):
        while True:
            try:
                command, args = self.menu.parse()
            except:
                continue